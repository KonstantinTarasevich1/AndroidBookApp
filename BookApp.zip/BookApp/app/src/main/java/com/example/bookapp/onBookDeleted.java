package com.example.bookapp;

public interface onBookDeleted {
    void bookDeleted(int id);
}
