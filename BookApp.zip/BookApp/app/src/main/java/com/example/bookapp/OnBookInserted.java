package com.example.bookapp;

import com.example.bookapp.models.Book;

public interface OnBookInserted {
    void bookInserted(Book b);
}
