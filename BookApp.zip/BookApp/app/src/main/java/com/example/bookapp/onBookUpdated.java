package com.example.bookapp;

public interface onBookUpdated {
    void bookUpdated(int id);

}
